    <!doctype html>
    <html lang="es">
      <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <!-- Font Roboto CSS -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
        <style>body{font-family:"Roboto" !important;}</style>

        <title>Lista de usuarios</title>
      </head>
      <body>

            <br>
                <div class="container">
              
                  <div class="row">
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                      <h1>Login usuarios</h1>
                      <form action="<?php echo base_url('') ?>usuarios" method="POST">
                        <label for="usuario">Usuario</label>
                        <input type="text" name="usuario" class="form-control" required="">
                        <label for="password">Password</label>
                        <input type="password" name="contraseña" class="form-control" required="">
                        <br>
                        <button class="btn btn-primary">Entrar</button>
                      </form>
                    </div>
                    <div class="col-sm-4"></div>
                  </div>
                </div>
                <p>Usuario: Nahumval</p><br>
                <p>Contraseña: 123</p>

            
            <h1 class="mt-5">Lista de usuarios</h1>
            
            <table class="table mt-4">
                <thead class="thead-light">
                    <tr>
                    <th scope="col">N°</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Contraseña</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $number=0; foreach($data as $key => $value): ?>
                        <tr>
                            <th scope="row"><?php echo $number++; ?></th>
                            <td><?php echo $value->usuario; ?></td>
                            <td><?php echo $value->contraseña; ?></td>
                            
                        </tr>
                    <?php endforeach; ?>

                </tbody>
            </table>
            
       

        <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

        <script>
            
            <?php if($this->session->flashdata("success")): ?>

                Swal.fire({
                    icon: 'success',
                    title: 'Good...',
                    text: '<?php echo $this->session->flashdata("success"); ?>',
                });
            <?php endif; ?>

        </script>
      </body>
    </html>