<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("Login_model");
	}





	public function index()
	{	
		$data = array("data"=>$this->Login_model->getUsers());

		$this->load->view('login',$data);
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function login() {

		$usuario = $this->request->getUser('usuario');
		$contraseña = $this->request->getUser('contraseña');
		$Usuario = new Usuarios();

		$datosUsuario = $Usuario->obtenerUsuario(['usuario' => $usuario]);

		if (count($datosUsuario) > 0 && 
			password_verify($contraseña, $datosUsuario[0]['contraseña'])) {

			$data = [
						"usuario" => $datosUsuario[0]['usuario'],
						"type" => $datosUsuario[0]['type']
					];

			$session = session();
			$session->set($data);

			return redirect()->to(base_url('/usuarios'))->with('mensaje','1');

		} else {
			return redirect()->to(base_url('/'))->with('mensaje','0');
		}


	}

	public function salir() {
		$session = session();
		$session->destroy();
		return redirect()->to(base_url('/'));
	}

	
}
